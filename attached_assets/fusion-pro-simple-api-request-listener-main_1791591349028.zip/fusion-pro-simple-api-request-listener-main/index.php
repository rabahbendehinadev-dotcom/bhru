<?php

/**
 * Fusion Pro Simple API Request Listener
 *
 * Supported actions:
 * - account_info
 * - products
 * - place-order
 *
 * Fusion Pro calls this file with ?action=<action>. For POST requests the
 * action stays in the query string and the payload is sent as JSON.
 */

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$rawInput = file_get_contents('php://input');
$jsonInput = json_decode($rawInput, true);
$input = $method === 'GET' ? $_GET : (is_array($jsonInput) ? $jsonInput : []);

$api_key = (string)($input['api_key'] ?? $_GET['api_key'] ?? '');

// Optional: set this value to require a matching api_key on every request.
$expected_api_key = '';
if ($expected_api_key !== '' && !hash_equals($expected_api_key, $api_key)) {
    http_response_code(401);
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid API key',
        'order_id' => '',
        'replay' => '',
        'data' => [],
    ], JSON_PRETTY_PRINT);
    exit;
}

$action = $_GET['action'] ?? 'undefined';

$status = 'error';
$message = 'Unknown action';
$data = [];
$replay = '';
$order_id = '';

$catalog = [
    'currency' => 'USD',
    'categories' => [
        'imei-checks' => [
            'name' => 'IMEI Checks',
            'type' => 'imei',
        ],
        'server-services' => [
            'name' => 'Server Services',
            'type' => 'server',
        ],
    ],
    'products' => [
        'imei-basic-check' => [
            'name' => 'Basic IMEI Check',
            'type' => 'imei',
            'cid' => 'imei-checks',
            'cids' => ['imei-checks'],
            'price' => 1.25,
            'time' => '1-5 minutes',
            'info_short' => base64_encode('Basic sample IMEI lookup. Replace this text with your service details.'),
            'fields' => [
                [
                    'type' => 'imei',
                    'name' => 'IMEI',
                    'description' => '15 digit IMEI number',
                    'required' => true,
                ],
            ],
        ],
        'account-credit-add' => [
            'name' => 'Account Credit Add',
            'type' => 'server',
            'cid' => 'server-services',
            'cids' => ['server-services'],
            'price' => 5.00,
            'time' => 'Instant',
            'info_short' => base64_encode('Adds sample credits to a supplier-side account. Replace this with your real service content.'),
            'fields' => [
                [
                    'type' => 'text',
                    'name' => 'username',
                    'description' => 'Customer username on the supplier system',
                    'required' => true,
                ],
            ],
        ],
    ],
];

switch ($action) {
    case 'account_info':
        $status = 'success';
        $message = 'Account information loaded';
        $data = [
            'email' => 'supplier@example.com',
            'balance' => 100,
            'currency' => 'USD',
            'info' => 'Demo listener account. Replace these values with live supplier data.',
        ];
        break;

    case 'products':
        $status = 'success';
        $message = 'Products loaded';
        $data = $catalog;
        break;

    case 'place-order':
        $IMEI = $input['IMEI'] ?? $input['imei'] ?? null;
        $product_id = $input['product_id'] ?? null;
        $Quantity = $input['Quantity'] ?? $input['quantity'] ?? 1;

        if ($product_id === 'imei-basic-check' && !$IMEI) {
            $status = 'error';
            $message = 'Missing IMEI';
            break;
        }

        if ($product_id) {
            $status = 'success';
            $message = 'Order placed';
            $order_id = uniqid('', true);
            $replay = "Demo result for {$product_id}. Quantity: {$Quantity}";
        }
        else {
            $status = 'error';
            $message = 'Missing product_id';
        }
        break;

    default:
        $status = 'error';
        $message = 'Unknown action';
        break;
}

$response = [
    'status' => $status,
    'message' => $message,
    'order_id' => $order_id,
    'replay' => $replay,
    'data' => $data,
];

echo json_encode($response, JSON_PRETTY_PRINT);
