# Fusion Pro Simple API Request Listener

This is a small example listener for the Fusion Pro `Custom Simple Request` order API.

Fusion Pro calls this listener with `?action=<action>`. The catalog is fetched from
the listener during Order API sync, then Fusion Pro caches the products and
categories in its `tblApis` sync table.

## Configure In Fusion Pro

1. Add supplier `Custom Simple Request`.
2. Set `API URL` to this listener URL, for example:

   ```text
   https://example.com/index.php
   ```

3. Set `Request Method` to `GET` or `POST`.
4. Enable `Action :: Account Info` if this listener should provide account balance.
5. Enable `Action :: Product/Service List` if this listener should provide products.
6. Run `Sync Order API` in Fusion Pro.

If `Action :: Product/Service List` is disabled, Fusion Pro uses its local fallback
demo products. Enable it when the product list should come from this listener.

## Supported Actions

### account_info

Request:

```text
GET /index.php?action=account_info&api_key=YOUR_KEY
```

Expected response:

```json
{
  "status": "success",
  "message": "Account information loaded",
  "data": {
    "email": "supplier@example.com",
    "balance": 100,
    "currency": "USD",
    "info": "Optional supplier note"
  }
}
```

### products

Request:

```text
GET /index.php?action=products&api_key=YOUR_KEY
```

Expected response:

```json
{
  "status": "success",
  "message": "Products loaded",
  "data": {
    "currency": "USD",
    "categories": {
      "imei-checks": {
        "name": "IMEI Checks",
        "type": "imei"
      }
    },
    "products": {
      "imei-basic-check": {
        "name": "Basic IMEI Check",
        "type": "imei",
        "cid": "imei-checks",
        "cids": ["imei-checks"],
        "price": 1.25,
        "time": "1-5 minutes",
        "info_short": "Base64 encoded short description",
        "fields": [
          {
            "type": "imei",
            "name": "IMEI",
            "description": "15 digit IMEI number",
            "required": true
          }
        ]
      }
    }
  }
}
```

Product IDs are the keys under `data.products`. Fusion Pro sends the selected key
back as `product_id` when placing an order.

Common field types are `text`, `imei`, `number`, and `enum`. For enum fields, add
an `options` array.

### place-order

Request:

```text
POST /index.php?action=place-order
Content-Type: application/json

{
  "api_key": "YOUR_KEY",
  "product_id": "imei-basic-check",
  "IMEI": "123456789012345",
  "Quantity": 1
}
```

Expected success response:

```json
{
  "status": "success",
  "message": "Order placed",
  "order_id": "supplier-order-id",
  "replay": "Order result or code"
}
```

Expected reject response:

```json
{
  "status": "error",
  "message": "Invalid IMEI",
  "order_id": "",
  "replay": "Invalid IMEI"
}
```

Fusion Pro treats `status=success` as successful. Any other status is mapped as a
rejected/error response by the Simple Request gateway.

## Customizing Products

Replace the `$catalog` array in `index.php` with your real product data. The data
can come from a database, a local file, or another API. Keep the output shape the
same:

```php
$data = [
    'currency' => 'USD',
    'categories' => [...],
    'products' => [...],
];
```

Use the action name `place-order`; do not use `place_order`.
