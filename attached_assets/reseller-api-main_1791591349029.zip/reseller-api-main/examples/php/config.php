<?php

declare(strict_types=1);

$baseUrl = rtrim(trim((string)getenv('DHRU_RESELLER_BASE_URL')), '/');
$bearerToken = trim((string)getenv('DHRU_RESELLER_TOKEN'));
$timeoutValue = trim((string)getenv('DHRU_RESELLER_TIMEOUT_SECONDS'));

if ($baseUrl === '' || filter_var($baseUrl, FILTER_VALIDATE_URL) === false) {
    throw new RuntimeException(
        'Set DHRU_RESELLER_BASE_URL to a valid base URL, for example ' .
        'https://store.example/api/reseller/v1.'
    );
}

$scheme = strtolower((string)parse_url($baseUrl, PHP_URL_SCHEME));
$host = strtolower((string)parse_url($baseUrl, PHP_URL_HOST));
$loopbackHosts = ['127.0.0.1', 'localhost', '::1', '[::1]'];
if ($scheme !== 'https' && !($scheme === 'http' && in_array($host, $loopbackHosts, true))) {
    throw new RuntimeException(
        'DHRU_RESELLER_BASE_URL must use HTTPS (HTTP is allowed only for localhost testing).'
    );
}
if (parse_url($baseUrl, PHP_URL_USER) !== null
    || parse_url($baseUrl, PHP_URL_PASS) !== null
    || parse_url($baseUrl, PHP_URL_QUERY) !== null
    || parse_url($baseUrl, PHP_URL_FRAGMENT) !== null) {
    throw new RuntimeException(
        'DHRU_RESELLER_BASE_URL must not contain credentials, a query string or a fragment.'
    );
}

if ($bearerToken === '' || preg_match('/[\r\n]/', $bearerToken)) {
    throw new RuntimeException('Set DHRU_RESELLER_TOKEN to your Reseller API Bearer token.');
}

$timeoutSeconds = null;
if ($timeoutValue !== '') {
    $timeoutSeconds = filter_var(
        $timeoutValue,
        FILTER_VALIDATE_INT,
        ['options' => ['min_range' => 1, 'max_range' => 900]]
    );
    if ($timeoutSeconds === false) {
        throw new RuntimeException('DHRU_RESELLER_TIMEOUT_SECONDS must be an integer from 1 to 900.');
    }
}

return [
    'BASE_URL' => $baseUrl,
    'BEARER_TOKEN' => $bearerToken,
    'TIMEOUT_SECONDS' => $timeoutSeconds,
];
