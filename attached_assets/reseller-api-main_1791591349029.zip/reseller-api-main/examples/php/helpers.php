<?php

declare(strict_types=1);

/**
 * Perform a cURL request.
 *
 * @param string $path Path relative to the configured API base URL.
 * @param string $method HTTP method: GET, POST, PUT, DELETE, etc.
 * @param array|null $headers Optional additional headers.
 * @param array|null $body Optional request body for POST/PUT requests.
 *
 * @return array Contains 'http_code' and 'response'.
 */
function callApi(string $path, string $method = 'GET', array $headers = [], ?array $body = null): array
{
    $config = loadConfig();
    if ($path === ''
        || $path[0] !== '/'
        || str_starts_with($path, '//')
        || str_contains($path, '://')
        || str_contains($path, '..')) {
        throw new InvalidArgumentException('API paths must be root-relative and remain below the configured base URL.');
    }

    $url = $config['BASE_URL'] . '/' . ltrim($path, '/');
    $method = strtoupper($method);
    $timeoutSeconds = $config['TIMEOUT_SECONDS'] ?? ($method === 'POST' ? 300 : 30);
    $ch = curl_init($url);
    if ($ch === false) {
        throw new RuntimeException('Unable to initialize cURL.');
    }

    $commonHeaders = [
        'Accept: application/json',
        'Authorization: Bearer ' . $config['BEARER_TOKEN'],
    ];

    if ($body !== null) {
        $commonHeaders[] = 'Content-Type: application/json';
        $encodedBody = json_encode($body, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedBody);
    }

    $allHeaders = array_merge($commonHeaders, $headers);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $allHeaders);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeoutSeconds);

    $response = curl_exec($ch);
    if ($response === false) {
        $error = curl_error($ch);
        if ($method === 'POST') {
            throw new RuntimeException(
                'The order transport failed and its outcome is unknown; verify the order before retrying. ' .
                'Transport detail: ' . $error
            );
        }
        throw new RuntimeException('API transport failed: ' . $error);
    }

    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);

    try {
        $decodedResponse = decodeJsonResponse($response);
    } catch (RuntimeException $exception) {
        if ($method === 'POST') {
            throw new RuntimeException(
                'The order response was invalid and its outcome is unknown; verify the order before retrying.',
                0,
                $exception
            );
        }
        throw $exception;
    }

    return ['http_code' => $httpCode, 'response' => $decodedResponse];
}

/** @return array<string,mixed> */
function decodeJsonResponse(string $response): array
{
    try {
        $decoded = json_decode($response, true, 512, JSON_THROW_ON_ERROR);
    } catch (JsonException $exception) {
        throw new RuntimeException('The API returned invalid JSON.', 0, $exception);
    }

    if (!is_array($decoded)) {
        throw new RuntimeException('The API response must be a JSON object.');
    }

    return $decoded;
}

/**
 * Print the complete response and report whether both transports agree it succeeded.
 *
 * @param array{http_code:int,response:array<string,mixed>} $result
 */
function printApiResult(array $result): bool
{
    echo 'HTTP Code: ' . $result['http_code'] . PHP_EOL;
    echo json_encode(
        $result['response'],
        JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
    ) . PHP_EOL;

    $apiCode = $result['response']['code'] ?? null;
    return $result['http_code'] >= 200
        && $result['http_code'] < 300
        && ($result['response']['status'] ?? null) === 'success'
        && is_numeric($apiCode)
        && (int)$apiCode >= 200
        && (int)$apiCode < 300;
}

/**
 * Load configurations from config.php.
 *
 * @return array Config settings as an associative array.
 */
function loadConfig(): array
{
    return include __DIR__ . '/config.php';
}
