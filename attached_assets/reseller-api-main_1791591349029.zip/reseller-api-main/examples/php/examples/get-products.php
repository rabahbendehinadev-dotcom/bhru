<?php

declare(strict_types=1);

require_once __DIR__ . '/../helpers.php';

// With no ID, products are keyed by the numeric product_id used when placing orders.
$productId = trim((string)getenv('DHRU_PRODUCT_ID'));
$path = '/products';

// Optional: pass a numeric product ID or UUID to retrieve one complete product record.
if ($productId !== '') {
    $path .= '?' . http_build_query(['product_id' => $productId]);
}

$result = callApi($path);
exit(printApiResult($result) ? 0 : 1);
