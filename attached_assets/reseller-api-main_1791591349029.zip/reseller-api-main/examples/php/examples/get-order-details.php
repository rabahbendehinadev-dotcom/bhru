<?php

declare(strict_types=1);

require_once __DIR__ . '/../helpers.php';

$orderUuid = trim((string)getenv('DHRU_ORDER_UUID'));
if ($orderUuid === '') {
    throw new RuntimeException(
        'Set DHRU_ORDER_UUID to one order UUID, or a comma-separated list of order UUIDs.'
    );
}

$result = callApi('/order?' . http_build_query(['order_uuid' => $orderUuid]));
exit(printApiResult($result) ? 0 : 1);
