<?php

declare(strict_types=1);

header('Content-Type: application/json');

/** @param array<string,mixed> $body */
function respond(int $status, array $body): never
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    respond(405, ['accepted' => false, 'message' => 'POST required.']);
}

$contentLength = filter_var($_SERVER['CONTENT_LENGTH'] ?? null, FILTER_VALIDATE_INT);
if ($contentLength !== false && $contentLength !== null && $contentLength > 65536) {
    respond(413, ['accepted' => false, 'message' => 'Invalid callback body.']);
}

$input = fopen('php://input', 'rb');
$raw = $input === false ? false : stream_get_contents($input, 65537);
if (is_resource($input)) {
    fclose($input);
}
if ($raw === false || strlen($raw) > 65536) {
    respond(413, ['accepted' => false, 'message' => 'Invalid callback body.']);
}

try {
    $payload = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
} catch (JsonException) {
    respond(400, ['accepted' => false, 'message' => 'Invalid JSON.']);
}

if (!is_array($payload)
    || !is_string($payload['reference_id'] ?? null)
    || !preg_match('/^[A-Za-z0-9-]{1,50}$/', $payload['reference_id'])
    || !is_string($payload['order_id'] ?? null)
    || !preg_match('/^[A-Za-z0-9-]{1,80}$/', $payload['order_id'])
    || !in_array($payload['status'] ?? null, ['success', 'rejected'], true)
    || !is_string($payload['replay'] ?? null)
    || base64_decode($payload['replay'], true) === false) {
    respond(400, ['accepted' => false, 'message' => 'Invalid callback fields.']);
}

/*
 * Store this event idempotently using order_id/reference_id, then verify the
 * final state with authenticated GET /order before releasing goods or codes.
 * The callback is a notification and does not carry a cryptographic signature.
 */

respond(200, ['accepted' => true]);
