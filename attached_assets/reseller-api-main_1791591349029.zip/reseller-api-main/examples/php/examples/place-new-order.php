<?php

declare(strict_types=1);

require_once __DIR__ . '/../helpers.php';

// WARNING: this request creates a real order and may debit the reseller wallet.
$productId = trim((string)getenv('DHRU_PRODUCT_ID'));
$referenceId = trim((string)getenv('DHRU_REFERENCE_ID'));
$feedbackUrl = trim((string)getenv('DHRU_FEEDBACK_URL'));
$productFieldsJson = trim((string)getenv('DHRU_ORDER_FIELDS_JSON'));
$quantity = trim((string)getenv('DHRU_QUANTITY'));

if ($productId === ''
    || !ctype_digit($productId)
    || ($numericProductId = filter_var(
        $productId,
        FILTER_VALIDATE_INT,
        ['options' => ['min_range' => 1]]
    )) === false) {
    throw new RuntimeException('Set DHRU_PRODUCT_ID to a numeric ID returned by GET /products.');
}
if (!preg_match('/^[A-Za-z0-9-]{1,50}$/', $referenceId)) {
    throw new RuntimeException(
        'Set DHRU_REFERENCE_ID to 1-50 letters, digits or hyphens and keep it unique.'
    );
}
if (filter_var($feedbackUrl, FILTER_VALIDATE_URL) === false
    || strtolower((string)parse_url($feedbackUrl, PHP_URL_SCHEME)) !== 'https') {
    throw new RuntimeException('Set DHRU_FEEDBACK_URL to a valid HTTPS callback URL.');
}

try {
    $productFields = json_decode($productFieldsJson ?: '{}', true, 512, JSON_THROW_ON_ERROR);
} catch (JsonException $exception) {
    throw new RuntimeException('DHRU_ORDER_FIELDS_JSON must be a JSON object.', 0, $exception);
}
if (!is_array($productFields) || ($productFields !== [] && array_is_list($productFields))) {
    throw new RuntimeException('DHRU_ORDER_FIELDS_JSON must be a JSON object.');
}
foreach (array_keys($productFields) as $fieldName) {
    if (in_array(strtolower((string)$fieldName), ['feedback_url', 'reference_id', 'quantity'], true)) {
        throw new RuntimeException(
            'Set feedback_url, reference_id and Quantity through their dedicated environment variables.'
        );
    }
}

$orderFields = array_merge($productFields, [
    'feedback_url' => $feedbackUrl,
    'reference_id' => $referenceId,
]);

// Quantity is optional. When omitted, the API defaults it to 1.
if ($quantity !== '') {
    $numericQuantity = filter_var(
        $quantity,
        FILTER_VALIDATE_INT,
        ['options' => ['min_range' => 1]]
    );
    if (!ctype_digit($quantity) || $numericQuantity === false) {
        throw new RuntimeException('DHRU_QUANTITY must be a positive whole number.');
    }
    $orderFields['Quantity'] = $numericQuantity;
}

$payload = [[
    'product_id' => $numericProductId,
    'fields' => [$orderFields],
]];

$result = callApi('/order', 'POST', [], $payload);
exit(printApiResult($result) ? 0 : 1);
