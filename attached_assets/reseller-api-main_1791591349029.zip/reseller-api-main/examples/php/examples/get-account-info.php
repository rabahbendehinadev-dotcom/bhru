<?php

declare(strict_types=1);

require_once __DIR__ . '/../helpers.php';

// Read-only: returns the profile and wallet selected when this API token was created.
$result = callApi('/account');
exit(printApiResult($result) ? 0 : 1);
