const { callApi, printApiResult } = require("../helpers");

async function main() {
    // With no ID, products are keyed by the numeric product_id used for orders.
    const productId = (process.env.DHRU_PRODUCT_ID || "").trim();
    const path = productId
        ? `/products?${new URLSearchParams({ product_id: productId })}`
        : "/products";

    if (!printApiResult(await callApi(path))) {
        process.exitCode = 1;
    }
}

main().catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
});
