const { callApi, printApiResult } = require("../helpers");

async function main() {
    const orderUuid = (process.env.DHRU_ORDER_UUID || "").trim();
    if (!orderUuid) {
        throw new Error(
            "Set DHRU_ORDER_UUID to one order UUID, or a comma-separated list of order UUIDs."
        );
    }

    const query = new URLSearchParams({ order_uuid: orderUuid });
    if (!printApiResult(await callApi(`/order?${query}`))) {
        process.exitCode = 1;
    }
}

main().catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
});
