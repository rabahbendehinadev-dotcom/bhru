const http = require("node:http");

const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || "127.0.0.1";

if (!Number.isInteger(port) || port < 1 || port > 65_535) {
    throw new Error("PORT must be an integer from 1 to 65535.");
}

function json(response, status, body) {
    response.writeHead(status, { "Content-Type": "application/json" });
    response.end(JSON.stringify(body));
}

const server = http.createServer((request, response) => {
    if (request.method !== "POST") {
        response.setHeader("Allow", "POST");
        json(response, 405, { accepted: false, message: "POST required." });
        return;
    }

    const chunks = [];
    let size = 0;
    let tooLarge = false;
    request.on("data", (chunk) => {
        size += chunk.length;
        if (size > 65_536) {
            tooLarge = true;
            return;
        }
        chunks.push(chunk);
    });
    request.on("end", () => {
        if (tooLarge) {
            json(response, 413, { accepted: false, message: "Invalid callback body." });
            return;
        }

        let payload;
        try {
            payload = JSON.parse(Buffer.concat(chunks).toString("utf8"));
        } catch {
            json(response, 400, { accepted: false, message: "Invalid JSON." });
            return;
        }

        if (!payload || Array.isArray(payload) || typeof payload !== "object") {
            json(response, 400, { accepted: false, message: "Invalid callback body." });
            return;
        }

        const referenceValid = typeof payload.reference_id === "string"
            && /^[A-Za-z0-9-]{1,50}$/.test(payload.reference_id);
        const orderValid = typeof payload.order_id === "string"
            && /^[A-Za-z0-9-]{1,80}$/.test(payload.order_id);
        const statusValid = ["success", "rejected"].includes(payload.status);
        const replayValid = typeof payload.replay === "string"
            && /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(payload.replay);

        if (!referenceValid || !orderValid || !statusValid || !replayValid) {
            json(response, 400, { accepted: false, message: "Invalid callback fields." });
            return;
        }

        /*
         * Store this event idempotently using order_id/reference_id, then verify
         * it with authenticated GET /order before releasing goods or codes.
         * The callback does not carry a cryptographic signature.
         */
        json(response, 200, { accepted: true });
    });
});

server.listen(port, host, () => {
    if (!["127.0.0.1", "localhost", "::1"].includes(host)) {
        console.warn("WARNING: the development feedback listener is exposed beyond localhost.");
    }
    console.log(`Feedback listener is running at http://${host}:${port}.`);
});
