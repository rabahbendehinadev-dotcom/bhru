const { callApi, printApiResult } = require("../helpers");

async function main() {
    // WARNING: this request creates a real order and may debit the reseller wallet.
    const productId = (process.env.DHRU_PRODUCT_ID || "").trim();
    const referenceId = (process.env.DHRU_REFERENCE_ID || "").trim();
    const feedbackUrl = (process.env.DHRU_FEEDBACK_URL || "").trim();
    const quantity = (process.env.DHRU_QUANTITY || "").trim();

    const numericProductId = Number(productId);
    if (!/^\d+$/.test(productId)
        || !Number.isSafeInteger(numericProductId)
        || numericProductId < 1) {
        throw new Error("Set DHRU_PRODUCT_ID to a numeric ID returned by GET /products.");
    }
    if (!/^[A-Za-z0-9-]{1,50}$/.test(referenceId)) {
        throw new Error(
            "Set DHRU_REFERENCE_ID to 1-50 letters, digits or hyphens and keep it unique."
        );
    }
    let parsedFeedbackUrl;
    try {
        parsedFeedbackUrl = new URL(feedbackUrl);
    } catch {
        throw new Error("DHRU_FEEDBACK_URL must be a valid HTTPS callback URL.");
    }
    if (parsedFeedbackUrl.protocol !== "https:") {
        throw new Error("DHRU_FEEDBACK_URL must be a valid HTTPS callback URL.");
    }

    let productFields;
    try {
        productFields = JSON.parse(process.env.DHRU_ORDER_FIELDS_JSON || "{}");
    } catch {
        throw new Error("DHRU_ORDER_FIELDS_JSON must be a JSON object.");
    }
    if (!productFields || Array.isArray(productFields) || typeof productFields !== "object") {
        throw new Error("DHRU_ORDER_FIELDS_JSON must be a JSON object.");
    }
    const reservedFields = new Set(["feedback_url", "reference_id", "quantity"]);
    if (Object.keys(productFields).some((name) => reservedFields.has(name.toLowerCase()))) {
        throw new Error(
            "Set feedback_url, reference_id and Quantity through their dedicated environment variables."
        );
    }

    const orderFields = {
        ...productFields,
        feedback_url: feedbackUrl,
        reference_id: referenceId,
    };

    // Quantity is optional. When omitted, the API defaults it to 1.
    if (quantity) {
        const numericQuantity = Number(quantity);
        if (!/^\d+$/.test(quantity)
            || !Number.isSafeInteger(numericQuantity)
            || numericQuantity < 1) {
            throw new Error("DHRU_QUANTITY must be a positive whole number.");
        }
        orderFields.Quantity = numericQuantity;
    }

    const payload = [{ product_id: numericProductId, fields: [orderFields] }];
    if (!printApiResult(await callApi("/order", "POST", {}, payload))) {
        process.exitCode = 1;
    }
}

main().catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
});
