const { callApi, printApiResult } = require("../helpers");

async function main() {
    // Read-only: returns the profile and wallet selected when this token was created.
    if (!printApiResult(await callApi("/account"))) {
        process.exitCode = 1;
    }
}

main().catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
});
