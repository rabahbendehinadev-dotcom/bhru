const BASE_URL = (process.env.DHRU_RESELLER_BASE_URL || "").trim().replace(/\/+$/, "");
const BEARER_TOKEN = (process.env.DHRU_RESELLER_TOKEN || "").trim();
const timeoutValue = (process.env.DHRU_RESELLER_TIMEOUT_SECONDS || "").trim();

if (!BASE_URL) {
    throw new Error(
        "Set DHRU_RESELLER_BASE_URL, for example https://store.example/api/reseller/v1."
    );
}

let parsedBaseUrl;
try {
    parsedBaseUrl = new URL(BASE_URL);
} catch {
    throw new Error("DHRU_RESELLER_BASE_URL must be a valid URL.");
}

const loopbackHosts = new Set(["127.0.0.1", "localhost", "[::1]"]);
if (parsedBaseUrl.protocol !== "https:"
    && !(parsedBaseUrl.protocol === "http:" && loopbackHosts.has(parsedBaseUrl.hostname))) {
    throw new Error("DHRU_RESELLER_BASE_URL must use HTTPS (HTTP is allowed only for localhost testing).");
}
if (parsedBaseUrl.username || parsedBaseUrl.password || parsedBaseUrl.search || parsedBaseUrl.hash) {
    throw new Error(
        "DHRU_RESELLER_BASE_URL must not contain credentials, a query string or a fragment."
    );
}

if (!BEARER_TOKEN || /[\r\n]/.test(BEARER_TOKEN)) {
    throw new Error("Set DHRU_RESELLER_TOKEN to your Reseller API Bearer token.");
}

let TIMEOUT_SECONDS = null;
if (timeoutValue) {
    if (!/^\d+$/.test(timeoutValue) || Number(timeoutValue) < 1 || Number(timeoutValue) > 900) {
        throw new Error("DHRU_RESELLER_TIMEOUT_SECONDS must be an integer from 1 to 900.");
    }
    TIMEOUT_SECONDS = Number(timeoutValue);
}

module.exports = { BASE_URL, BEARER_TOKEN, TIMEOUT_SECONDS };
