const config = require("./config");

/**
 * Perform an HTTP request using Node.js built-in fetch.
 *
 * @param {string} path - Path relative to the configured API base URL.
 * @param {string} method - HTTP method (e.g., GET, POST, PUT, DELETE).
 * @param {Object} headers - Optional additional headers.
 * @param {Object} body - Optional request body for POST/PUT requests.
 * @returns {Promise<Object>} Contains HTTP status code and response data.
 */
async function callApi(path, method = "GET", headers = {}, body = null) {
    if (typeof path !== "string"
        || !path.startsWith("/")
        || path.startsWith("//")
        || path.includes("://")
        || path.includes("..")) {
        throw new Error("API paths must be root-relative and remain below the configured base URL.");
    }

    const baseUrl = new URL(`${config.BASE_URL}/`);
    const url = new URL(path.slice(1), baseUrl);
    const basePath = baseUrl.pathname.endsWith("/") ? baseUrl.pathname : `${baseUrl.pathname}/`;
    if (url.origin !== baseUrl.origin || !url.pathname.startsWith(basePath)) {
        throw new Error("The API path resolved outside the configured base URL.");
    }

    method = method.toUpperCase();
    const timeoutSeconds = config.TIMEOUT_SECONDS || (method === "POST" ? 300 : 30);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutSeconds * 1000);

    try {
        const commonHeaders = {
            Accept: "application/json",
            Authorization: `Bearer ${config.BEARER_TOKEN}`,
            ...(body !== null ? { "Content-Type": "application/json" } : {}),
        };

        const response = await fetch(url, {
            method,
            headers: { ...commonHeaders, ...headers },
            body: body === null ? undefined : JSON.stringify(body),
            signal: controller.signal,
        });

        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (error) {
            throw new Error(`The API returned invalid JSON (HTTP ${response.status}).`, { cause: error });
        }

        return {
            http_code: response.status,
            response: data,
        };
    } catch (error) {
        if (error.name === "AbortError") {
            if (method === "POST") {
                throw new Error(
                    "The order request timed out. Its outcome is unknown; verify the order before retrying."
                );
            }
            throw new Error(`The API request timed out after ${timeoutSeconds} seconds.`);
        }
        if (method === "POST") {
            throw new Error(
                `The order transport or response failed and its outcome is unknown; verify the order before retrying. Detail: ${error.message}`,
                { cause: error }
            );
        }
        throw error;
    } finally {
        clearTimeout(timeout);
    }
}

function printApiResult(result) {
    console.log(`HTTP Code: ${result.http_code}`);
    console.log(JSON.stringify(result.response, null, 2));

    const apiCode = Number(result.response?.code);
    return result.http_code >= 200
        && result.http_code < 300
        && result.response?.status === "success"
        && Number.isFinite(apiCode)
        && apiCode >= 200
        && apiCode < 300;
}

module.exports = { callApi, printApiResult };
