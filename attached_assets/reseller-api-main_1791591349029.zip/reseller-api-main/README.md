# Dhru Fusion Pro Reseller API

Server-side PHP and Node.js examples for integrating an external application
with a Dhru Fusion Pro workspace.

The Reseller API can read the reseller account and catalogue, place paid
orders, retrieve order status, and notify an HTTPS callback when an order
reaches a final state.

## API base and authentication

Use your own Fusion Pro workspace domain:

```text
https://YOUR-WORKSPACE-DOMAIN/api/reseller/v1
```

Every request must send the generated **API token** as a Bearer credential:

```http
Authorization: Bearer YOUR_API_TOKEN
Accept: application/json
```

Create the token from the reseller/client account's API Access screen. Reseller
API access must be enabled for that account. A token is bound to:

- the selected wallet currency, which controls returned prices and balance;
- its expiry date; and
- its optional exact source-IP allowlist.

Use the generated API token, not the separately returned API key. Keep the
token on your server, never in browser JavaScript, mobile application code,
source control, URLs, or logs.

## Supported endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/account` | Read the reseller profile and token-currency balance |
| `GET` | `/products` | List available categories and products |
| `GET` | `/products?product_id=...` | Read one product by numeric ID or UUID |
| `POST` | `/order` | Create one or more paid orders |
| `GET` | `/order?order_uuid=...` | Read one order or a comma-separated list |

`POST /order` is a write operation. It creates orders and may debit the
reseller wallet. There is no dry-run mode.

## Requirements

- PHP 8.1 or newer with the cURL extension; or
- Node.js 18 or newer. The Node examples use built-in `fetch` and have no
  package dependency.

Configure either language with environment variables:

```bash
export DHRU_RESELLER_BASE_URL='https://store.example/api/reseller/v1'
export DHRU_RESELLER_TOKEN='replace-with-api-token'
```

The repository ignores `.env`, but the examples intentionally do not load it
for you. Export the values through your shell or production secret manager.
Read requests time out after 30 seconds and order requests after 300 seconds by
default. Set `DHRU_RESELLER_TIMEOUT_SECONDS` to a value from 1-900 only when
your environment requires a different limit.

## Examples

### Account

```bash
php examples/php/examples/get-account-info.php
node examples/nodejs/examples/get-account-info.js
```

A successful response uses the common response envelope:

```json
{
  "status": "success",
  "message": "Your account details have been retrieved successfully.",
  "code": 200,
  "data": {
    "currency": "USD",
    "balance": "450.78000",
    "name": "Example Reseller",
    "email": "reseller@example.com"
  }
}
```

### Products

```bash
php examples/php/examples/get-products.php
node examples/nodejs/examples/get-products.js
```

The keys under `data.products` are numeric product IDs. Use that key as
`product_id` when placing an order:

```json
{
  "status": "success",
  "code": 200,
  "data": {
    "currency": "USD",
    "categories": {
      "C12": {
        "name": "IMEI Services",
        "type": "imei"
      }
    },
    "products": {
      "123": {
        "name": "Example IMEI Service",
        "type": "imei",
        "cid": "C12",
        "cids": ["C12"],
        "price": "1.25",
        "time": "1-5 Minutes",
        "fields": [
          {
            "type": "imei",
            "name": "IMEI",
            "required": true
          }
        ]
      }
    }
  }
}
```

To retrieve one complete record, including both `product_id` and
`product_uuid`:

```bash
DHRU_PRODUCT_ID=123 php examples/php/examples/get-products.php
DHRU_PRODUCT_ID=123 node examples/nodejs/examples/get-products.js
```

Always build order inputs from the returned `fields` schema. Fields vary by
product.

### Place an order

Each top-level item identifies one product. Each object in its `fields` list
creates one order for that product.

```json
[
  {
    "product_id": 123,
    "fields": [
      {
        "IMEI": "490154203237518",
        "feedback_url": "https://merchant.example/webhooks/dhru-order",
        "reference_id": "merchant-order-1001",
        "Quantity": 1
      }
    ]
  }
]
```

Rules:

- `product_id` is the numeric key returned by `GET /products`. A valid
  `product_uuid` is also accepted, but do not mix identifier styles in one
  multi-product request.
- `fields` must contain at least one order object.
- `feedback_url` is required for every order and must be HTTPS.
- `reference_id` is required for every order. Use a unique value; the accepted
  format is a string of 1-50 ASCII letters, digits, or hyphens.
- `Quantity` is optional and defaults to `1`. When provided, it must be a
  positive whole number and satisfy the product's advertised limits.
- All other required values come from that product's `fields` schema.

The runnable examples require explicit values so they cannot accidentally send
their old sample order:

```bash
export DHRU_PRODUCT_ID='123'
export DHRU_REFERENCE_ID='merchant-order-1001'
export DHRU_FEEDBACK_URL='https://merchant.example/webhooks/dhru-order'
export DHRU_ORDER_FIELDS_JSON='{"IMEI":"490154203237518"}'
export DHRU_QUANTITY='1'

php examples/php/examples/place-new-order.php
# or
node examples/nodejs/examples/place-new-order.js
```

One product with one order returns one nested result group:

```json
{
  "status": "success",
  "message": "1 Order submitted",
  "code": 200,
  "data": [
    [
      {
        "order_uuid": "D25040311111228272516",
        "amount": 1.25,
        "currency_code": "USD",
        "reference_id": "merchant-order-1001"
      }
    ]
  ]
}
```

`amount` is the monetary total charged in `currency_code`, not the order
quantity. A returned item can also include `note`, for example when the same
active order is detected as a duplicate.

Batch size is limited by the connected supplier's order-batch setting, or to
1,000 order rows when no supplier limit applies. Workspace/client placement
limits can return HTTP `429`; honor the `Retry-After` header.

An order timeout, connection failure, or invalid response is an **unknown
outcome**: the server may already have created and charged the order before the
client stopped waiting. Do not blindly retry `POST /order`. Reconcile the order
in Fusion Pro first, using the unique `reference_id` and any response/order UUID
you received.

### Receive final order feedback

Fusion Pro sends JSON to the order's `feedback_url` only when the order
becomes `success` or `rejected`:

```json
{
  "reference_id": "merchant-order-1001",
  "order_id": "D25040311111228272516",
  "status": "success",
  "replay": "UHJvY2VzcyBjb21wbGV0ZWQ="
}
```

- `order_id` is the Fusion Pro `order_uuid`.
- `replay` is base64-encoded. Decode it only as untrusted text/data.
- Return HTTP `200` quickly and process idempotently by
  `order_id`/`reference_id`.
- The callback does not currently carry a general cryptographic signature.
  Treat it as a notification and verify the final state with authenticated
  `GET /order` before releasing goods, codes, credits, or other value.

Minimal receivers are included:

```bash
php -S 127.0.0.1:8080 examples/php/examples/receive-order-feedback.php
PORT=8080 node examples/nodejs/examples/receive-order-feedback.js
```

These localhost commands are for development. Fusion Pro requires the
configured callback URL itself to be publicly reachable over HTTPS.
The included receivers only validate and acknowledge the sample payload; add
durable idempotent storage and authenticated order verification before use.

### Get order details

```bash
export DHRU_ORDER_UUID='D25040311111228272516'
php examples/php/examples/get-order-details.php
# or
node examples/nodejs/examples/get-order-details.js
```

Single-order response:

```json
{
  "status": "success",
  "message": "Order Details",
  "code": 200,
  "data": {
    "quantity": 1,
    "replay": "Process completed",
    "status": "success",
    "date_completed": "2025-04-03 11:25:35",
    "date": "2025-04-03 11:11:12"
  }
}
```

For a bulk lookup, pass comma-separated order UUIDs in `DHRU_ORDER_UUID`.
The response `data` is then keyed by each requested UUID.

Possible order states are `new`, `pre-checking`, `accepted`, `in-process`,
`pending`, `verify`, `success`, and `rejected`. A single unknown UUID returns
HTTP `404`. In a bulk lookup, an unknown UUID is instead represented inside an
otherwise successful response as:

```json
{
  "status": "rejected",
  "replay": "Invalid order uuid!"
}
```

Treat that bulk placeholder as "not found", not as proof that a real order was
rejected.

## Error handling

Responses use this envelope; `data`, `info`, and `meta` are optional and empty
top-level fields can be omitted:

```json
{
  "status": "success or error",
  "message": "Human-readable result",
  "code": 200,
  "data": {},
  "info": {},
  "meta": {}
}
```

Check both the HTTP status and the JSON `status`/`code`. For compatibility,
some order validation failures currently use HTTP/code `201` with
`status: "error"`; therefore any 2xx response must not automatically be
treated as a successful order.

Authentication failures return `401` or `402`, missing records can return
`404`, placement limits return `429`, and temporary service failures can
return `503`.

## Postman

Import the version-controlled collection:

[`postman/Dhru_Fusion_Pro_Reseller_API.postman_collection.json`](postman/Dhru_Fusion_Pro_Reseller_API.postman_collection.json)

Set its `base_url`, `bearer_token`, `product_id`, `reference_id`,
`feedback_url`, `order_fields_json`, optional `quantity`, and `order_uuid`
variables before sending requests. Use `{}` for `order_fields_json` when a
product has no additional fields. The collection rejects non-HTTPS remote base
URLs. The place-order request creates a real paid order and is skipped unless
`confirm_paid_order` is explicitly set to `YES`. Its script builds the payload
from the validated variables and resets that confirmation to `NO` before each
attempt. It also clears the collection's `reference_id` after building the
request, so every paid request requires a fresh opt-in and reference. The
exported token value is blank; mark your local `bearer_token` variable as
sensitive in Postman and never export its current value.

## Security checklist

- Use HTTPS for the API and callback.
- Store the Bearer token only in a server-side secret manager.
- Restrict the token to known source IPs when possible.
- Give every order a unique `reference_id`.
- Make callback handling idempotent and verify final state with `GET /order`.
- Never log tokens or full order fields containing customer data.

## License

MIT.
